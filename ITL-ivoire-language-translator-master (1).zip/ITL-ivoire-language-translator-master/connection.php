 <?php
	$servername = "localhost";
	$username = "root";
	$password = "";
	$dbname = "itl_part2";

	$con = mysqli_connect($servername, $username, $password, $dbname);
	?>